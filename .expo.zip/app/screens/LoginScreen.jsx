import React, { useState, useEffect } from 'react';
import { Image, StyleSheet, Text, TouchableOpacity, View, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {globalStyles}  from '../styles/GlobalStyles';
import { router } from 'expo-router';
import * as Google from 'expo-auth-session/providers/google';
import * as WebBrowser from 'expo-web-browser';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

WebBrowser.maybeCompleteAuthSession();

const LoginScreen = () => {
  const [userInfo, setUserInfo] = useState(null);
  const [loading, setLoading] = useState(false);

  const [request, response, promptAsync] = Google.useAuthRequest({
    androidClientId: '671394807556-i4ke2ovb1ghtm7f5n3mkrmhnhvbbsa8f.apps.googleusercontent.com',
    redirectUri: 'com.chinnasivakrishna.learning:/oauth2redirect',
    scopes: ['profile', 'email']
  });

  useEffect(() => {
    checkExistingToken();
  }, []);

  useEffect(() => {
    handleSignInResponse();
  }, [response]);

  const checkExistingToken = async () => {
    try {
      const token = await AsyncStorage.getItem('userToken');
      const userData = await AsyncStorage.getItem('userData');
      
      if (token && userData) {
        // Verify token validity with the backend
        try {
          const response = await axios.get('https://googlesingin.onrender.com/api/auth/user', {
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
          
          if (response.status === 200) {
            setUserInfo(JSON.parse(userData));
            router.push('/screens/tabs/DashboardScreen');
          } else {
            // If token verification fails, clear storage and stay on login
            await AsyncStorage.removeItem('userToken');
            await AsyncStorage.removeItem('userData');
          }
        } catch (error) {
          console.error('Token verification failed:', error);
          // Clear invalid token
          await AsyncStorage.removeItem('userToken');
          await AsyncStorage.removeItem('userData');
        }
      }
    } catch (error) {
      console.error('Error checking existing session:', error);
    }
  };

  const handleSignInResponse = async () => {
    if (response?.type === 'success') {
      setLoading(true);
      const { authentication } = response;
      
      try {
        const userInfoResponse = await fetch(
          'https://www.googleapis.com/userinfo/v2/me',
          {
            headers: { Authorization: `Bearer ${authentication.accessToken}` },
          }
        );
        
        const googleUserInfo = await userInfoResponse.json();
        
        const backendResponse = await axios.post('https://googlesingin.onrender.com/api/auth/google', {
          googleId: googleUserInfo.id,
          email: googleUserInfo.email,
          name: googleUserInfo.name,
          photoUrl: googleUserInfo.picture,
          accessToken: authentication.accessToken,
          idToken: authentication.idToken 
        });
        
        const { token, user } = backendResponse.data;
        
        await AsyncStorage.setItem('userToken', token);
        await AsyncStorage.setItem('userData', JSON.stringify(user));
        
        setUserInfo(user);
        router.push('/screens/tabs/DashboardScreen');
      } catch (error) {
        console.error('Error in Google sign-in process:', error);
        Alert.alert('Sign-in Failed', 'Unable to sign in with Google. Please try again.');
      } finally {
        setLoading(false);
      }
    }
  };

  const handleGoogleLogin = async () => {
    try {
      setLoading(true);
      await promptAsync();
    } catch (error) {
      console.error('Error initiating Google sign-in:', error);
      Alert.alert('Error', 'Failed to start Google sign-in');
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={globalStyles.safeArea}>
      <View style={globalStyles.loginView}>
        <Image source={require('../../assets/images/intro.jpg')} style={globalStyles.introImg} resizeMode="contain"/>
        <TouchableOpacity 
          style={globalStyles.signButton} 
          onPress={handleGoogleLogin}
          disabled={loading}
        >
          <Text style={styles.buttonText}>
            {loading ? 'Signing in...' : 'Sign In with Google'}
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

export default LoginScreen;

const styles = StyleSheet.create({
  register: {
    marginTop: 15,
    textAlign: 'center',
    color: '#555',
    textDecorationLine: 'underline'
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center'
  }
});