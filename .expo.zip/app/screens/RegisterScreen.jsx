import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const RegisterScreen = () => {
  return (
    <View>
      <Text>RegisterScreen</Text>
    </View>
  )
}

export default RegisterScreen

const styles = StyleSheet.create({})