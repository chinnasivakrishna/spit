import { StyleSheet, Text, View, Image, TouchableOpacity, TextInput, ActivityIndicator, FlatList, Alert } from 'react-native'
import React, { useState, useEffect } from 'react'
import { SafeAreaView } from 'react-native-safe-area-context'
import { globalStyles } from '../../styles/GlobalStyles'
import Icon from 'react-native-vector-icons/FontAwesome'
import axios from 'axios'
import AsyncStorage from '@react-native-async-storage/async-storage'
import { router } from 'expo-router'

const API_URL = 'https://googlesingin.onrender.com/api';

const DashboardScreen = () => {
  const [userData, setUserData] = useState({
    name: 'User',
    photoUrl: null,
    greeting: 'Hello'
  });
  const [loading, setLoading] = useState(true);
  const [recommendedGroups, setRecommendedGroups] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);

  useEffect(() => {
    fetchUserData();
  }, []);

  const fetchUserData = async () => {
    try {
      setLoading(true);
      const token = await AsyncStorage.getItem('userToken');
     
      
      const response = await axios.get(`${API_URL}/user/profile`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      
      if (!response.data.success) {
        throw new Error('Failed to fetch user data');
      }
      
      const { user, greeting } = response.data;
      
      setUserData({
        name: user.name,
        photoUrl: user.photoUrl,
        greeting: greeting
      });
      
      // Fetch recommended groups (mock data for now)
      setRecommendedGroups([
        { id: 1, name: 'Tech Enthusiasts', description: 'Discuss latest tech trends', image: require('../../../assets/images/abstract.avif') },
        { id: 2, name: 'Coffee Lovers', description: 'For those who love coffee', image: require('../../../assets/images/abstract.avif') },
      ]);
      
    } catch (error) {
      console.error('Error fetching user data:', error);
      
      // Check if token is invalid
      if (error.response && (error.response.status === 401 || error.response.status === 403)) {
        Alert.alert('Session Expired', 'Please login again');
        handleLogout();
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async (text) => {
    setSearchQuery(text);
    
    if (text.length < 2) {
      setSearchResults([]);
      setIsSearching(false);
      return;
    }
    
    setIsSearching(true);
    
    try {
      // In a real app, you would call your search API here
      // For now, using mock data
      setTimeout(() => {
        setSearchResults([
          { id: 1, type: 'user', name: 'John Doe', description: 'Software Developer' },
          { id: 2, type: 'group', name: 'React Native Devs', description: 'Group for RN developers' }
        ]);
        setIsSearching(false);
      }, 500);
    } catch (error) {
      console.error('Search error:', error);
      setIsSearching(false);
    }
  };

  const handleLogout = async () => {
    try {
      await AsyncStorage.removeItem('userToken');
      await AsyncStorage.removeItem('userData');
      router.replace('/');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const renderGroupItem = ({ item }) => (
    <TouchableOpacity style={styles.groupContainer}>
      <View style={styles.groupPhoto}>
        <Image source={item.image} style={styles.groupImage} />
      </View>
      <View style={styles.groupDetails}>
        <Text style={styles.groupName}>{item.name}</Text>
        <Text style={styles.groupDescription}>{item.description}</Text>
      </View>
    </TouchableOpacity>
  );

  if (loading) {
    return (
      <SafeAreaView style={[globalStyles.safeArea, styles.loadingContainer]}>
        <ActivityIndicator size="large" color="#007bff" />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={globalStyles.safeArea}>
      <View style={styles.header}>
        <Image 
          source={
            userData.photoUrl 
              ? { uri: userData.photoUrl } 
              : require('../../../assets/images/profile-img.jpg')
          } 
          style={styles.avatar} 
        />
        <View style={styles.greeting}>
          <Text style={styles.greetingText}>{userData.greeting}</Text>
          <Text style={styles.userName}>{userData.name}</Text>
        </View>
        <View style={styles.icons}>
          <TouchableOpacity>
            <Icon name="bell-o" size={24} style={styles.icon} />
          </TouchableOpacity>
          <TouchableOpacity onPress={handleLogout}>
            <Icon name="sign-out" size={24} style={styles.icon} />
          </TouchableOpacity>
        </View>
      </View>

      <TextInput 
        style={styles.searchBar} 
        placeholder="People, Groups, Events ..." 
        value={searchQuery}
        onChangeText={handleSearch}
      />
      
      {isSearching ? (
        <ActivityIndicator style={styles.searchLoader} size="small" color="#007bff" />
      ) : searchQuery.length > 0 ? (
        <FlatList
          data={searchResults}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <TouchableOpacity style={styles.searchResultItem}>
              <Icon name={item.type === 'user' ? 'user' : 'users'} size={24} style={styles.searchIcon} />
              <View style={styles.searchResultContent}>
                <Text style={styles.searchResultTitle}>{item.name}</Text>
                <Text style={styles.searchResultDesc}>{item.description}</Text>
              </View>
            </TouchableOpacity>
          )}
          style={styles.searchResults}
          ListEmptyComponent={() => (
            <Text style={styles.noResults}>No results found</Text>
          )}
        />
      ) : (
        <>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recommended Groups</Text>
            <TouchableOpacity>
              <Text style={styles.seeAll}>See All</Text>
            </TouchableOpacity>
          </View>
          
          <FlatList
            data={recommendedGroups}
            keyExtractor={(item) => item.id.toString()}
            renderItem={renderGroupItem}
            showsVerticalScrollIndicator={false}
          />
        </>
      )}
    </SafeAreaView>
  )
}

export default DashboardScreen;

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  greeting: {
    flex: 1,
    marginLeft: 10,
  },
  greetingText: {
    fontSize: 14,
    color: '#888',
  },
  userName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  icons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    marginLeft: 16,
    color: '#000',
  },
  searchBar: {
    margin: 16,
    padding: 12,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 8,
  },
  searchLoader: {
    marginTop: 20
  },
  searchResults: {
    marginHorizontal: 16,
  },
  searchResultItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  searchIcon: {
    marginRight: 12,
    color: '#007bff',
  },
  searchResultContent: {
    flex: 1,
  },
  searchResultTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  searchResultDesc: {
    fontSize: 14,
    color: '#888',
  },
  noResults: {
    textAlign: 'center',
    marginTop: 20,
    color: '#888',
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  seeAll: {
    color: '#007bff',
  },
  groupContainer: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    marginHorizontal: 16,
    marginVertical: 8,
    borderRadius: 8,
    padding: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  groupPhoto: {
    marginRight: 12,
  },
  groupImage: {
    width: 75,
    height: 75,
    borderRadius: 8,
  },
  groupDetails: {
    flex: 1,
    justifyContent: 'center',
  },
  groupName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  groupDescription: {
    fontSize: 14,
    color: '#888',
    marginTop: 4,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  }
});