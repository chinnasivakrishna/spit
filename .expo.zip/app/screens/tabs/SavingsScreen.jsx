import { SafeAreaView, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { globalStyles } from '../../styles/GlobalStyles'

const SavingsScreen = () => {
  return (
    <SafeAreaView style={globalStyles.safeArea}>
    <View>
      <Text>SavingsScreen</Text>
    </View>
    </SafeAreaView>
  )
}

export default SavingsScreen

const styles = StyleSheet.create({})