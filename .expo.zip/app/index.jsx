import { Redirect } from 'expo-router';
const index = () => {
  return <Redirect href="/screens/LoginScreen" />;
}


export default index;