import { StyleSheet, Text, View, Image, TouchableOpacity, TextInput } from 'react-native'
import React from 'react'
import { SafeAreaView } from 'react-native-safe-area-context'
import { globalStyles } from '../../styles/GlobalStyles'
import Navbar from '../../components/Navbar'
import Icon from 'react-native-vector-icons/FontAwesome'

const DashboardScreen = () => {
  return (
    <SafeAreaView style={globalStyles.safeArea}>
      <View style={styles.header}>
        <Image source={require('../../../assets/images/profile-img.jpg')} style={styles.avatar} />
        <View style={styles.greeting}>
          <Text style={styles.greetingText}>Good Morning</Text>
          <Text style={styles.userName}>Nicholas Escobar</Text>
        </View>
        <View style={styles.icons}>
          <TouchableOpacity>
            <Icon name="bell-o" size={24} style={styles.icon} />
          </TouchableOpacity>
        </View>
      </View>

      <TextInput style={styles.searchBar} placeholder="People, Groups, Events ..." />

        <TouchableOpacity style={styles.bannerButton}>
          <View style={styles.groupContainer}>
            <View style={styles.groupPhoto}>
              <Image source={require('../../../assets/images/abstract.avif')} style={styles.groupImage} />
            </View>
            <View style={styles.groupDetails}>
              <Text style={styles.groupName}>Group Name</Text>
              <Text style={styles.groupDescription}>Group Description</Text>
            </View>
          </View>
        </TouchableOpacity>

    </SafeAreaView>
  )
}

export default DashboardScreen

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  greeting: {
    flex: 1,
    marginLeft: 10,
  },
  greetingText: {
    fontSize: 14,
    color: '#888',
  },
  userName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  icons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    marginLeft: 10,
    color: '#000',
  },
  banner: {
    backgroundColor: '#007bff',
    padding: 16,
    borderRadius: 8,
    margin: 16,
    alignItems: 'center',
  },
  bannerText: {
    color: '#fff',
    fontSize: 16,
    marginBottom: 8,
  },
  bannerButton: {
    backgroundColor: '#fff',
    marginHorizontal: 16,
    borderRadius: 4,
  },
  bannerButtonText: {
    color: '#007bff',
    fontWeight: 'bold',
  },
  searchBar: {
    margin: 16,
    padding: 12,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 8,
  },
  categories: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: 16,
  },
  categoriesTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  viewAll: {
    color: '#007bff',
  },
  categoryIcons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    margin: 16,
  },
  category: {
    alignItems: 'center',
    padding: 16,
    borderRadius: 8,
    backgroundColor: '#f0f0f0',
  },
  groupContainer: {
    flexDirection: 'row',
  },
  groupPhoto: {
    marginRight: 10,
  },
  groupImage: {
    width: 75,
    height: 75,
  },
  groupDetails: {
    flex: 1,
  },
  groupName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  groupDescription: {
    fontSize: 14,
    color: '#888',
  },
})   