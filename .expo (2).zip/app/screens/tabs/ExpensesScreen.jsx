import { StyleSheet, Text, View, Image, TouchableOpacity, ScrollView } from 'react-native';
import React from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/FontAwesome';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faHandshake } from '@fortawesome/free-regular-svg-icons';

const ExpensesScreen = () => {
  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView>
        <View style={styles.header}>
          <View>
            <Text style={styles.welcomeText}>Welcome back,</Text>
            <Text style={styles.userName}>Tanjiro Kamado</Text>
          </View>
          <Image source={require('../../../assets/images/profile-img.jpg')} style={styles.avatar} />
        </View>
        <View style={styles.balanceContainer}>
          <Text style={styles.balance}>$32,149.00</Text>
          <Icon name="eye" size={24} color="#222" style={styles.eyeIcon} />
          <Text style={styles.balanceLabel}>Account Balance</Text>
        </View>
        <View style={styles.actions}>
          <TouchableOpacity style={styles.actionButton}>
            <FontAwesomeIcon icon={faHandshake} size={28} color="#222" />
            <Text style={styles.actionText}>Send</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionButton}>
            <Icon name="arrow-down" size={24} color="#222" />
            <Text style={styles.actionText}>Withdraw</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionButton}>
            <Icon name="line-chart" size={24} color="#222" />
            <Text style={styles.actionText}>Invest</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionButton}>
            <Icon name="plus" size={24} color="#222" />
            <Text style={styles.actionText}>Add</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.transactions}>
          <View style={styles.transactionHeader}>
            <Text style={styles.transactionTitle}>Transactions</Text>
            <TouchableOpacity>
              <Text style={styles.seeAll}>See all</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.transactionItem}>
            <Icon name="vimeo" size={24} color="#00bfff" />
            <View style={styles.transactionDetails}>
              <Text style={styles.transactionName}>Subscription payments</Text>
              <Text style={styles.transactionDate}>20 May, 13:28</Text>
            </View>
            <Text style={styles.transactionAmountNegative}>-$20.00</Text>
          </View>
          <View style={styles.transactionItem}>
            <Icon name="youtube" size={24} color="#ff0000" />
            <View style={styles.transactionDetails}>
              <Text style={styles.transactionName}>Creator payments</Text>
              <Text style={styles.transactionDate}>20 May, 10:32</Text>
            </View>
            <Text style={styles.transactionAmountPositive}>+$12.99</Text>
          </View>
          <View style={styles.transactionItem}>
            <Icon name="paypal" size={24} color="#003087" />
            <View style={styles.transactionDetails}>
              <Text style={styles.transactionName}>Purchase payments</Text>
              <Text style={styles.transactionDate}>20 May, 09:24</Text>
            </View>
            <Text style={styles.transactionAmountNegative}>-$32.00</Text>
          </View>
        </View>
        <View style={styles.budgetContainer}>
          <Text style={styles.budgetTitle}>Weekly spending: $320</Text>
          <Text style={styles.budgetText}>You're staying right on track with your weekly budget.</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default ExpensesScreen;

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  welcomeText: {
    color: '#222',
    fontSize: 16,
  },
  userName: {
    color: '#222',
    fontSize: 18,
    fontWeight: 'bold',
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  balanceContainer: {
    alignItems: 'center',
    marginVertical: 20,
    color: '#222',
  },
  balance: {
    color: '#14A44D',
    fontSize: 32,
    fontWeight: 'bold',
  },
  eyeIcon: {
    marginVertical: 10,
  },
  balanceLabel: {
    color: '#222',
    fontSize: 14,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginVertical: 20,
  },
  actionButton: {
    alignItems: 'center',
  },
  actionText: {
    color: '#222',
    marginTop: 8,
  },
  transactions: {
    color: '#222',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 16,
    marginHorizontal: 16,
    marginTop: -20, // Overlap effect
  },
  transactionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  transactionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  seeAll: {
    color: '#007bff',
  },
  transactionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  transactionDetails: {
    flex: 1,
    marginLeft: 10,
  },
  transactionName: {
    fontSize: 16,
  },
  transactionDate: {
    color: '#888',
    fontSize: 12,
  },
  transactionAmountNegative: {
    color: '#ff0000',
    fontSize: 16,
  },
  transactionAmountPositive: {
    color: '#00bfff',
    fontSize: 16,
  },
  budgetContainer: {
    backgroundColor: '#f0f0f0',
    borderRadius: 20,
    padding: 16,
    margin: 16,
  },
  budgetTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  budgetText: {
    color: '#555',
    marginTop: 8,
  },
});